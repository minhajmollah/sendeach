=== SendEach ===
Contributors: btechj
Donate link: https://sendeach.com/
Tags: cloud messaging,bulk messaging,ai chatbot,email marketing,whatsapp marketting,sms marketing,transactional email,whatsapp otp,sms otp
Requires at least: 5.7
Tested up to: 6.2.2
Stable tag: 1.2
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

SendEach: Streamline messaging with a versatile cloud communication platform. Connect through WhatsApp, SMS, email, and more. Own accounts for free sending

== Description ==
The SendEach WordPress plugin is a powerful tool that enhances your website\'s functionality. To access advanced features, register on our main site, SendEach.com, and enter the provided authentication code in the plugin settings. By default, the plugin enables seamless OTP message delivery through WhatsApp and email. Additionally, for a seamless user experience, configure your login and registration pages to display SendEach forms. For further assistance, visit our website\'s help section or reach out to our support team. Empower your website with SendEach and elevate your communication strategy.

== Installation ==
To install the SendEach WordPress plugin, follow these steps:

1. Log in to your WordPress admin dashboard.
2. Navigate to the \"Plugins\" section and click on \"Add New.\"
3. In the search bar, type \"SendEach\" and hit enter.
4. Locate the SendEach plugin from the search results and click on \"Install Now.\"
5. After the installation is complete, click on \"Activate\" to activate the plugin.
6. Once activated, you will see the SendEach plugin settings in your WordPress dashboard.
7. To access advanced features, register on our main site, SendEach.com, and obtain the authentication code.
8. Enter the authentication code in the SendEach plugin settings to unlock additional functionality.
9. By default, the plugin will allow you to send OTP messages through WhatsApp and email.
10. For a seamless user experience, configure your login and registration pages to display SendEach forms.

If you encounter any issues during the installation process or need further assistance, please refer to our documentation or reach out to our support team for help. Enjoy the enhanced communication capabilities of the SendEach WordPress plugin on your website!

== Frequently Asked Questions ==
Q: What is SendEach?
A: SendEach is a cloud communication platform that enables users to send marketing and OTP authentication messages through various channels, including WhatsApp, SMS, and email.

Q: How can I send messages through SendEach?
A: To send messages, you can use the SendEach platform by connecting your device to the cloud. You can send messages via WhatsApp, SMS, or email using your own accounts.

Q: Are there any limitations on the number of messages I can send?
A: With our paid plan, you can send unlimited messages without any restrictions. However, during the free evaluation period, messages will be watermarked.

Q: Can I use my own WhatsApp account to send messages?
A: Yes, you can utilize your own WhatsApp account to send marketing and authentication messages through SendEach.

Q: Is there a WordPress plugin available for SendEach?
A: Yes, we provide a WordPress plugin that enables OTP authentication and integration with your WordPress website. It offers additional features and enhanced functionality.

Q: How do I install the SendEach WordPress plugin?
A: To install the SendEach WordPress plugin, log in to your WordPress admin dashboard, go to \"Plugins,\" search for \"SendEach,\" install it, and activate it. Further configuration options will be available in your WordPress settings.

Q: Where can I find more information or get help with SendEach?
A: You can visit our website at SendEach.com for documentation, tutorials, and additional resources. If you require further assistance, feel free to reach out to our support team through the provided contact channels.

== Screenshots ==
1. This screenshot showcases the SendEach dashboard, providing a comprehensive view of your messaging activities. The user interface is clean and intuitive, displaying message logs, statistics, and various communication channels such as WhatsApp, SMS, and email. corresponds to screenshot3.png
2. In this screenshot, we see the SendEach WordPress plugin settings page. It allows users to configure their authentication code, select message delivery options.  corresponds to screenshot1.png
3. This screenshot showcases how to customize the appearance of SendEach forms on login and registration pages. The settings are easy to navigate and provide flexibility in integrating SendEach with your WordPress website.  corresponds to screenshot2.png

== Changelog ==
First Release version 1.2

== Upgrade Notice ==
First release