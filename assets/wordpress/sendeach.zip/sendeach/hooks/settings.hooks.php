<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('SndEch_Nc_Settings_Hooks')) {
  class SndEch_Nc_Settings_Hooks extends SndEch_NC_Hooks
  {
    public function admin_hooks()
    {
      // add menu page
      add_action('admin_menu', [$this, 'sndech_add_menu_page']);

      // register settings
      add_action('admin_init', [$this, 'sndech_register_settings']);

      // enqueue scripts
      add_action('admin_enqueue_scripts', [$this, 'sndech_enqueue_scripts']);
      
    }

    public function public_hooks()
    {
         add_action( 'wp_footer', [$this,'wp_footer']);
    }

    public function common_hooks()
    {

    }

    public function wp_footer(){
      $settings = get_option('sendeach_settings');
      $webbot_accesstoken = isset($settings['sendeach_webbot_accesstoken_field']) ? $settings['sendeach_webbot_accesstoken_field'] : '';
      if($webbot_accesstoken == 'yes'){
        echo '<button class="btn text-decoration-none whatsapp_float p-0" id="sendeach-chats-button"><i class="bi bi-chat-text" style="font-size: 30px"></i></button>';
      }
    }
    public function cn_update($input) {
      $settings = get_option('sendeach_settings');

      $login_page_id = isset($settings['sendeach_login_page']) ? $settings['sendeach_login_page'] : '';
      $register_page_id = isset($settings['sendeach_register_page']) ? $settings['sendeach_register_page'] : '';
      $sendeach_input_login_form = isset($settings['sendeach_input_login_form']) ? $settings['sendeach_input_login_form'] : '';
      $sendeach_input_register_form = isset($settings['sendeach_input_register_form']) ? $settings['sendeach_input_register_form'] : '';
      if ($input['sendeach_input_login_form']) {
        // if ($sendeach_input_login_form) {
        // }else{
          
            $login_page_id=$input['sendeach_login_page'];
          
          $data = array(
            'ID' => $login_page_id,
            'post_content' =>'[nc_login_registration_form type="login"]',
           );
          wp_update_post($data);
        //}
      }
      if ($input['sendeach_input_register_form']) {
        /*if ($sendeach_input_register_form) {
        }else{*/
           
          $register_page_id=$input['sendeach_register_page'];
          
          $data = array(
            'ID' => $register_page_id,
            'post_content' =>'[nc_login_registration_form type="register"]',
           );
          wp_update_post( $data );
        //}

      }
      return $input;
    }

    
    /*
    * Add menu page
    */
    public function sndech_add_menu_page()
    {
      add_menu_page(
        __('SendEach', 'sendeach'),
        __('SendEach', 'sendeach'),
        'manage_options',
        'sendeach',
        [$this, 'sndech_render_menu_page'],
        'dashicons-email-alt',
        6
      );
    }

    /**
     * Render menu page
     */
    public function sndech_render_menu_page()
    {
      $this->sndech_load_template('admin/settings');
    }

    /**
     * Register settings
     */
    public function sndech_register_settings()
    {
      register_setting('sendeach_settings', 'sendeach_settings', [
        'type' => 'array',
        'sanitize_callback'=>[$this,'cn_update'],
      ]);

      // register section for API Key
      add_settings_section(
        'sendeach_api_key_section',
        __('Authentication', 'sendeach'),
        [$this, 'sndech_render_api_key_section'],
        'sendeach'
      );

      //register field for checkbox to use admin api key or custom api key
      add_settings_field(
        'sendeach_use_admin_api_key',
        __('Use admin API Key', 'sendeach'),
        [$this, 'sndech_render_use_admin_api_key_field'],
        'sendeach',
        'sendeach_api_key_section'
      );

      // register field for API Key
      add_settings_field(
        'sendeach_api_key',
        __('API Key', 'sendeach'),
        [$this, 'sndech_render_api_key_field'],
        'sendeach',
        'sendeach_api_key_section'
      );


      add_settings_section(
        'sendeach_un_ue_section',
        __('Group Name for Email Group', 'sendeach'),
        [$this, 'sndech_render_un_ue_section'],
        'sendeach',
      );

      add_settings_field(
        'sndech_un_ue_username',
        __('Group Name', 'sendeach'),
        [$this, 'sndech_un_ue_username_field'],
        'sendeach',
        'sendeach_un_ue_section'
      );


      add_settings_section(
        'sendeach_un_up_section',
        __('Group Name for Phone Group', 'sendeach'),
        [$this, 'sndech_render_un_up_section'],
        'sendeach',
      );

      add_settings_field(
        'sndech_un_up_username',
        __('Group Name', 'sendeach'),
        [$this, 'sndech_un_up_username_field'],
        'sendeach',
        'sendeach_un_up_section'
      );

      // pick pages section
      add_settings_section(
        'sendeach_pick_pages_section',
        __('Select pages', 'sendeach'),
        [$this, 'sndech_render_pick_pages_section'],
        'sendeach',
      );

      // pick login form page
      add_settings_field(
        'sendeach_pick_login_page',
        __('Login page', 'sendeach'),
        [$this, 'sndech_render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_login_page',
        ]
      );

      // input form
      add_settings_field(
        'sendeach_pick_input_page',
        __('Input Login Form in page', 'sendeach'),
        [$this, 'sndech_render_pick_page_input_login_form_field'],
        'sendeach',
        'sendeach_pick_pages_section'
      );

      // pick register form page
      add_settings_field(
        'sendeach_pick_register_page',
        __('Register page', 'sendeach'),
        [$this, 'sndech_render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_register_page',
        ]
      );

      // input register form
      add_settings_field(
        'sendeach_pick_input_register_page',
        __('Input Register Form in page', 'sendeach'),
        [$this, 'sndech_render_pick_page_input_register_form_field'],
        'sendeach',
        'sendeach_pick_pages_section'
      );

      // pick terms and conditions page
      add_settings_field(
        'sendeach_pick_terms_and_conditions_page',
        __('Terms and conditions page', 'sendeach'),
        [$this, 'sndech_render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_terms_and_conditions_page',
        ]
      );
      add_settings_field(
        'sendeach_redirect_url',
        __('Redirect url', 'sendeach'),
        [$this, 'sndech_render_redirect_url'],
        'sendeach',
        'sendeach_pick_pages_section',
      );

      // OTP protocol
      add_settings_section(
        'sendeach_otp_protocol_section',
        __('OTP Protocol', 'sendeach'),
        [$this, 'sndech_render_otp_section'],
        'sendeach',
      );

      //input form
      add_settings_field(
        'sendeach_pick_input_page',
        __('Input Login Form in page', 'sendeach'),
        [$this, 'sndech_render_otp_protocol'],
        'sendeach',
        'sendeach_otp_protocol_section'
      );

      // Forms titles section
      add_settings_section(
        'sendeach_forms_titles_section',
        __('Forms titles', 'sendeach'),
        [$this, 'sndech_render_forms_titles_section'],
        'sendeach',
      );

      // Login form title
      add_settings_field(
        'sendeach_login_form_title',
        __('Login form title', 'sendeach'),
        [$this, 'sndech_render_forms_titles_field'],
        'sendeach',
        'sendeach_forms_titles_section',
        [
          'id' => 'sendeach_login_form_title',
          'default' => 'Login'
        ]
      );

      // Register form title
      add_settings_field(
        'sendeach_register_form_title',
        __('Register form title', 'sendeach'),
        [$this, 'sndech_render_forms_titles_field'],
        'sendeach',
        'sendeach_forms_titles_section',
        [
          'id' => 'sendeach_register_form_title',
          'default' => 'Register'
        ]
      );
      //Register form shortcode
      add_settings_field(
        'sendeach_button_color',
        __('Change color of button', 'sendeach'),
        [$this, 'sndech_render_button_color'],
        'sendeach',
        'sendeach_forms_titles_section',
        
      );

      add_settings_section(
        'sendeach_webbot_section',
        __('SendEach AI Chatbot', 'sendeach'),
        [$this, 'sndech_render_webbot_section'],
        'sendeach'
      );

      // add support link field
      add_settings_field(
        'sendeach_webbot_accesstoken_field',
        __('AI Chatbot Enable', 'sendeach'),
        [$this, 'sndech_render_webbot_field'],
        'sendeach',
        'sendeach_webbot_section',
      );

      // add support section
      add_settings_section(
        'sendeach_support_section',
        __('Support', 'sendeach'),
        [$this, 'sndech_render_support_section'],
        'sendeach'
      );

      // add support link field
      add_settings_field(
        'sendeach_support_link',
        __('Support link', 'sendeach'),
        [$this, 'sndech_render_support_link_field'],
        'sendeach',
        'sendeach_support_section'
      );




      if(isset($_POST['sendeach_settings']) && trim($_POST['sendeach_settings']['api_key']) != ''){
        $apiKey = $_POST['sendeach_settings']['api_key'];

        $users = get_users();

        if(isset($_POST['sendeach_settings']['sndech_un_ue_username']) && trim($_POST['sendeach_settings']['sndech_un_ue_username']) != ''){
            $gid = sanitize_text_field($_POST['sendeach_settings']['sndech_un_ue_username']);
            $apiUrl = "https://sendeach.com/api/email-groups/$gid/emails";
            $udata_arr = array();
            foreach ($users as $user) 
              $udata_arr['data'][] = array('name'=>substr($user->display_name,0,49),'email' => $user->user_email);
            
            if(get_option('SendEachAPI_EmailsRespective','no') != 'yes'){
                $response = wp_remote_post(
                  $apiUrl,
                  array(
                      'method' => 'POST',
                      'httpversion' => '1.1',
                      'sslverify' => false,
                      'headers' => array(
                          'Content-Type' => 'application/json',
                          'Authorization' => 'Bearer ' . $apiKey
                      ),
                      'body' => json_encode($udata_arr)
                  )
                );

                

                if (!is_wp_error($response)) {
                    $responseData = json_decode(wp_remote_retrieve_body($response), true);

                    if ($responseData['success']) 
                        update_option('SendEachAPI_EmailsRespective','yes');
                    
                }// if (!is_wp_error($response

            } // if(get_option('SendEachAPI_EmailsRespective'

        } // if(trim($_POST['sendeach_settings']['sndech_un_ue_username'])



        
        if(isset($_POST['sendeach_settings']['sndech_un_up_username']) && trim($_POST['sendeach_settings']['sndech_un_up_username']) != ''){
          $gid = sanitize_text_field($_POST['sendeach_settings']['sndech_un_up_username']);
          $apiUrl = "https://sendeach.com/api/phone-groups/$gid/phones";
          $udata_arr = array();
          foreach ($users as $user){
            $whatsNum = get_metadata('user',$user->ID,'_sendeach_whatsapp_number',true);
            $woo_whatsNum = get_metadata('user',$user->ID,'billing_phone',true);
            if($whatsNum && strlen($whatsNum) !== false)
                $udata_arr['data'][] = array('name'=>substr($user->display_name,0,49),'contact_no' => $whatsNum);
            elseif($woo_whatsNum && strlen($woo_whatsNum) !== false)
                $udata_arr['data'][] = array('name'=>substr($user->display_name,0,49),'contact_no' => $woo_whatsNum);
          }
          
          if(get_option('SendEachAPI_ContactsRespective','no') != 'yes'){
              $response = wp_remote_post(
                $apiUrl,
                array(
                    'method' => 'POST',
                    'httpversion' => '1.1',
                    'sslverify' => false,
                    'headers' => array(
                        'Content-Type' => 'application/json',
                        'Authorization' => 'Bearer ' . $apiKey
                    ),
                    'body' => json_encode($udata_arr)
                )
              );

              
             // die(print_r('<pre>').print_r($response));

              if (!is_wp_error($response)) {
                  $responseData = json_decode(wp_remote_retrieve_body($response), true);

                  if ($responseData['success']) 
                      update_option('SendEachAPI_ContactsRespective','yes');
                  
              }// if (!is_wp_error($response

          } // if(get_option('SendEachAPI_ContactsRespective'

      } // if(trim($_POST['sendeach_settings']['sndech_un_up_username'])

    } // if(isset($_POST['sendeach_settings']) && apikey




    } // public function END



    public function sndech_render_un_ue_section(){}
    public function sndech_un_ue_username_field(){
      $settings = get_option('sendeach_settings');
      
                // API endpoint URL
          $url = 'https://sendeach.com/api/email-groups';

          $api_key = $settings['api_key'];
          // Set headers
          $headers = [
              'Authorization' => 'Bearer ' . $api_key,
          ];

          // Set cURL options
          $args = [
              'headers' => $headers,
              'httpversion' => '1.1',
              'sslverify' => false,
              'method' => 'GET'
          ];

          // Make the API request
          $response = wp_remote_post($url, $args);
          // Check for errors
          if (is_wp_error($response)) {
            return; 
          }
          // Retrieve the response body
          $response_body = wp_remote_retrieve_body($response);

          // Parse the response
          $groupData = json_decode($response_body, true);
          
          //print_r($groupData);

          if ($groupData['success']) {
            
                $groupNames = $groupData['group'];

                // Display the dropdown list
                echo '<select name="sendeach_settings[sndech_un_ue_username]">';
                foreach ($groupNames as $group) {
                    echo '<option value="' . $group['id'] . '">' . $group['name'] . '</option>';
                }
                echo '</select>';
              } else {
                // Display an error message
                ?>
                <p><?php esc_html_e('Kindly Add An Email Group in your SendEach Account', 'sendeach')?></p>
                <?php
              }
    }
    public function sndech_un_ue_useremail_field(){
      $settings = get_option('sendeach_settings');
      $un_ue_email = isset($settings['sndech_un_ue_useremail']) ? $settings['sndech_un_ue_useremail'] : '';?>
      <input type="text" name="sendeach_settings[sndech_un_ue_useremail]" value="<?php echo $un_ue_email?>" />
<?php
    }

    public function sndech_render_un_up_section(){}
    public function sndech_un_up_username_field(){
            $settings = get_option('sendeach_settings');
      
                    // API endpoint URL
              $url = 'https://sendeach.com/api/phone-groups';

              $api_key = $settings['api_key'];
              // Set headers
              $headers = [
                  'Authorization' => 'Bearer ' . $api_key,
              ];

              // Set cURL options
              $args = [
                  'headers' => $headers,
                  'httpversion' => '1.1',
                  'sslverify' => false,
                  'method' => 'GET'
              ];

              // Make the API request
              $response = wp_remote_post($url, $args);
              // Check for errors
              if (is_wp_error($response)) {

              }
              // Retrieve the response body
              $response_body = wp_remote_retrieve_body($response);

              // Parse the response
              $groupData = json_decode($response_body, true);
              

              if ($groupData['success']) {
                
                    $groupNames = $groupData['group'];

                    // Display the dropdown list
                    echo '<select name="sendeach_settings[sndech_un_up_username]">';
                    foreach ($groupNames as $group) {
                        echo '<option value="' . $group['id'] . '">' . $group['name'] . '</option>';
                    }
                    echo '</select>';
                  } else {
                    // Display an error message
                    ?>
                    <p><?php esc_html_e('Kindly Add A Phone Group in your SendEach Account', 'sendeach')?></p>
                    <?php
                  }
    }
    public function sndech_un_up_userphone_field(){
      $settings = get_option('sendeach_settings');
      $un_up_phone = isset($settings['sndech_un_up_userphone']) ? $settings['sndech_un_up_userphone'] : '';?>
      <input type="text" name="sendeach_settings[sndech_un_up_userphone]" value="<?php echo $un_up_phone?>" />
<?php
    }


    public function sndech_render_webbot_section(){}

    public function sndech_render_webbot_field(){
      $settings = get_option('sendeach_settings');
      $webbot_accesstoken = isset($settings['sendeach_webbot_accesstoken_field']) ? $settings['sendeach_webbot_accesstoken_field'] : '';?>
      <input type="checkbox" name="sendeach_settings[sendeach_webbot_accesstoken_field]" value="yes" <?php echo $webbot_accesstoken == 'yes' ? 'checked=checked' : '' ?> />
<?php
    }
    /**
     * Render API Key section
     */
    public function sndech_render_api_key_section()
    {?>
        <span id="sendeach_api_key_section_description" style="display: none;"><?php esc_html_e('Enter your API Key to authenticate with SendEach', 'sendeach')?></span>
      <?php
    }

    /**
     * Render API Key field
     */
    public function sndech_render_api_key_field()
    {
      $settings = get_option('sendeach_settings');
      $api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
      $url = "https://sendeach.com/docs/api-tokens";?>
      <input type="text" name="sendeach_settings[api_key]" value="<?php echo $api_key?>" /><br />
      <a style="margin-top: 5px;" class="button button-primary-alt" href="<?php echo  $url?>" target="_blank"><?php esc_html_e('Get API KEY', 'sendeach')?></a>
      <?php
    }

    /**
     * Render checkbox to use admin api key or custom api key
     */
    public function sndech_render_use_admin_api_key_field()
    {
      $settings = get_option('sendeach_settings');

      $use_admin_api_key = isset($settings['use_admin_api_key']) ? $settings['use_admin_api_key'] : '';

      ?><input type="checkbox" name="sendeach_settings[use_admin_api_key]" value="1" <?php echo checked(1, $use_admin_api_key, false) ?> />
      <?php
    }

    /**
     * Enqueue scripts
     */
    public function sndech_enqueue_scripts()
    {
      // check if we are on the right page
      if (get_current_screen()->id !== 'toplevel_page_sendeach') {
        return;
      }

      // enqueue scripts
      wp_enqueue_script('sendeach-admin', $this->sndech_get_asset_url('js/sendeach-settings.js'), ['jquery'], '1.0.0', true);
    }

    /**
     * Render pick pages section
     */
    public function sndech_render_pick_pages_section()
    {
      esc_html_e('Select pages to use for login, register and terms and conditions', 'sendeach');
    }

    /**
     * Render pick page select section
     */
    public function sndech_render_pick_page_select_field($args)
    {
      $id = $args['id'];
      $value = get_option('sendeach_settings');
      $page_id = isset($value[$id]) ? $value[$id] : '';

      $pages = get_pages();
      if ($id=='sendeach_login_page' OR $id=='sendeach_register_page') {
        $att_required="required";
      }else{
        $att_required='';
      }
      ?><select name="sendeach_settings[<?php echo $id ?>]" <?php echo $att_required?>>
          <option value=""><?php esc_html_e('Select page', 'sendeach')?></option>
<?php
      foreach ($pages as $page) {?>
        <option value="<?php echo $page->ID?>" <?php echo selected($page->ID, $page_id, false) ?>><?php echo $page->post_title ?></option>
        <?php
      }

      ?></select><?php
      if ($id=='sendeach_register_page') {?>
        <br /><?php esc_html_e('shortcode for Registration page [nc_login_registration_form type="register"]', 'sendeach')?>
          <?php
      }
      if ($id=='sendeach_login_page') {?>
        <br /><?php esc_html_e('shortcode for login page [nc_login_registration_form type="login"]', 'sendeach');
      }
    }
    public function sndech_render_redirect_url($args)
    {
      
      $value = get_option('sendeach_settings');
      $sendeach_redirect_url = isset($value['sendeach_redirect_url']) ? $value['sendeach_redirect_url'] : '';?>
      <input type="text" name="sendeach_settings[sendeach_redirect_url]" value="<?php echo $sendeach_redirect_url?>" /><br />
      <small><?php esc_html_e('Redirect if user already login', 'sendeach')?></small><?php
      
    }

    

    /**
     * Render forms titles section
     */
    public function sndech_render_forms_titles_section()
    {
     esc_html_e('Enter forms titles', 'sendeach');
    }

    /**
     * Render forms titles field
     */
    public function sndech_render_forms_titles_field($args)
    {
      $id = $args['id'];
      $default = $args['default'];
      $value = get_option('sendeach_settings');
      $title = isset($value[$id]) ? $value[$id] : $default;
      ?>
      <input type="text" name="sendeach_settings[<?php echo $id?>]" value="<?php echo $title?>" /><?php
    }
    public function sndech_render_button_color()
    {
      $default = $args['default'];
      $value = get_option('sendeach_settings');

      $btn_background = isset($value['btn_background']) ? $value['btn_background'] : '1';
      $btn_text = isset($value['btn_text']) ? $value['btn_text'] : '1';
      $btn_hover_background = isset($value['btn_hover_background']) ? $value['btn_hover_background'] : '1';
      ?>
      <label><?php esc_html_e('Background Color', 'sendeach')?></label><br />
      <input style="width: 100px;" type="color" name="sendeach_settings[btn_background]" value="<?php echo $btn_background?>" /><br />
      <label><?php esc_html_e('Text Color', 'sendeach')?></label><br />
      <input style="width: 100px;" type="color" name="sendeach_settings[btn_text]" value="<?php echo $btn_text?>" /><br />
      <label><?php esc_html_e('Hover Background', 'sendeach')?></label><br />
      <input style="width: 100px;" type="color" name="sendeach_settings[btn_hover_background]" value="<?php echo $btn_hover_background?>" /><?php
    }
    public function sndech_render_login_form_shortcode()
    {
      echo '[nc_login_registration_form type="login"]';
    }
    


    /**
     * Render support section
     */
    public function sndech_render_support_section()
    {
      esc_html_e("Open ticket to request new features, report and issue, learn more about plugin and API Keys or to donate to developer", 'sendeach');
    }
    public function sndech_render_otp_section()
    {
      esc_html_e("", 'sendeach');
    }

    /**
     * Render support link field
     */
    public function sndech_render_support_link_field()
    {
      $url = "https://sendeach.com/docs/support";
      ?>
      <a class="button button-primary-alt" href="<?php echo $url?>" target="_blank"><?php esc_html_e('Contact support', 'sendeach')?></a><?php
    }

    /**
     * input form
     */
    public function sndech_render_pick_page_input_login_form_field()
    {
      $value = get_option('sendeach_settings');
      $input_form = isset($value['sendeach_input_login_form']) ? $value['sendeach_input_login_form'] : '1';

      ?>
      <input type="hidden" name="sendeach_settings[sendeach_input_login_form]" value="0" />
      <input type="checkbox" name="sendeach_settings[sendeach_input_login_form]" value="1" <?php echo checked('1', $input_form, false)?> /><br /><?php

    }
    /**
     * input OTP protocol
     */
    public function sndech_render_otp_protocol()
    {
      $value = get_option('sendeach_settings');
      $whatsapp = isset($value['whatsapp']) ? $value['whatsapp'] : '0';
      $sms = isset($value['sms']) ? $value['sms'] : '0';
      $email = isset($value['email']) ? $value['email'] : '0';

      $api_key = isset($value['use_admin_api_key']) ? $value['use_admin_api_key'] : '0';
      $cn_api_key = isset($value['api_key']) ? $value['api_key'] : '0';
      if ($api_key==0 && $cn_api_key!='') {
        $cn_val=1;
        $cn_val_des='';
      }else{
        $cn_val=0;
        $cn_val_des='disabled';
      }
      ?>
        <input type="checkbox" name="sendeach_settings[whatsapp]" value="1" <?php echo checked('1', $whatsapp, false)?> /><?php esc_html_e('Whatsapp', 'sendeach')?> <br />
      <input type="checkbox" name="sendeach_settings[email]" value="1" <?php echo checked('1', $email, false) ?> /><?php esc_html_e('Email', 'sendeach')?> <br />
      <input <?php echo $cn_val_des?> type="checkbox" name="sendeach_settings[sms]" value="1" <?php echo checked('1', $sms, false)?> /><?php esc_html_e('Sms', 'sendeach')?><br /><?php
      if ($cn_val_des) {?>
        <p><?php esc_html_e('for enable sms protocol disable admin api and add your API Key', 'sendeach')?></p><?php
      }
      
    }

    /**
     * input register form
     */
    public function sndech_render_pick_page_input_register_form_field()
    {
      $value = get_option('sendeach_settings');
      $input_form = isset($value['sendeach_input_register_form']) ? $value['sendeach_input_register_form'] : '1';

      ?>      
      <input type="hidden" name="sendeach_settings[sendeach_input_register_form]" value="0" />
      <input type="checkbox" name="sendeach_settings[sendeach_input_register_form]" value="1" <?php echo checked('1', $input_form, false)?> /><br /><?php
      
    }
  }
}
