<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('SndEch_NC_Hooks_Example')) {
  class SndEch_NC_Hooks_Example extends SndEch_NC_Hooks
  {
    public function admin_hooks()
    {
    }

    public function public_hooks()
    {
    }

    public function common_hooks()
    {
    }
  }
}
