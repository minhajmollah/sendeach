<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!function_exists('sndech_nc_session')) {
  /**
   * Get session manager instance
   *
   * @return SndEch_NC_Session_Manager
   */
  function sndech_nc_session()
  {
    return SndEch_NC_Session_Manager::sndech_get_instance();
  }
}
