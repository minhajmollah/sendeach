<?php

if (!defined('ABSPATH')) exit;

if (!function_exists('sndech_nc_sendeach_send_whatsapp_message')) {
  /**
   * Send OTP code to user
   * 
   * @param string $phone_number
   * @param string $message
   * @return boolean
   */
  function sndech_nc_sendeach_send_whatsapp_message(string $phone_number, string $message)
  {
    $url = 'https://sendeach.com/api/whatsapp/send';
    $token = sndech_nc_sendeach_get_api_key();

    $response = wp_remote_post($url, [
      'headers' => [
        'Authorization' => 'Bearer ' . $token,
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
      ],
      'body' => json_encode([
        "recipients" => [$phone_number],
        'message' => $message,
        "whatsapp_device" => null
      ])
    ]);

    $status = wp_remote_retrieve_response_code($response);

    return $status === 200;
  }
}

if (!function_exists('sndech_nc_sendeach_send_admin_whatsapp_message')) {
  /**
   * Send OTP code to user
   * 
   * @param string $phone_number
   * @param string $otp
   * @return boolean
   */
  function sndech_nc_sendeach_send_admin_whatsapp_message(string $phone_number, string $otp)
  {
    $url = 'https://sendeach.com/api/public/whatsapp/otp/send';
    $response = wp_remote_post($url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
      ],
      'body' => json_encode([
        'otp' => $otp,
        "domain" => get_site_url(),
        "phone" => $phone_number,
      ])
    ]);

    $status = wp_remote_retrieve_response_code($response);

    return $status === 200;
  }
}

if (!function_exists('sndech_nc_sendeach_send_email_message')) {
  /**
   * Send OTP code to user
   * 
   * @param string $user_email
   * @param string $message
   * @return boolean
   */
  function sndech_nc_sendeach_send_email_message(string $user_email, string $message)
  {
    $url = 'https://sendeach.com/api/email/send';
    $token = sndech_nc_sendeach_get_api_key();
    $website_title = get_bloginfo('name');
    $response = wp_remote_post($url, [
      'headers' => [
        'Authorization' => 'Bearer ' . $token,
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
      ],
      'body' => json_encode([
        "email" => [$user_email],
        'message' => $message,
        'subject'=>$website_title.'- Verification OTP',
        'from_name'=>$website_title,
        'reply_to_email'=>''
      ])
    ]);

    $status = wp_remote_retrieve_response_code($response);

    return $status === 200;
  }
}
if (!function_exists('sndech_nc_sendeach_send_admin_email_message')) {
  /**
   * Send OTP code to user
   * 
   * @param string $user_email
   * @param string $message
   * @return boolean
   */
  function sndech_nc_sendeach_send_admin_email_message(string $user_email, string $otp)
  {
    $url = 'https://sendeach.com/api/public/email/otp/send';
    $response = wp_remote_post($url, [
      'headers' => [
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
      ],
      'body' => json_encode([
        'otp' => $otp,
        "domain" => get_site_url(),
        "email" => $user_email,
      ])
    ]);
    $status = wp_remote_retrieve_response_code($response);
    return $status === 200;
  }
}

if (!function_exists('sndech_nc_sendeach_send_sms_message')) {
  /**
   * Send OTP code to user
   * 
   * @param string $phone_number
   * @param string $message
   * @return boolean
   */
  function sndech_nc_sendeach_send_sms_message(string $phone_number, string $message)
  {
    $url = 'https://sendeach.com/api/send_sms';
    $token = sndech_nc_sendeach_get_api_key();

    $response = wp_remote_post($url, [
      'headers' => [
        'Authorization' => 'Bearer ' . $token,
        'Content-Type' => 'application/json',
        'Accept' => 'application/json'
      ],
      'body' => json_encode([
        "recipients" => [$phone_number],
        'message' => $message,
        "device_id" => null
      ])
    ]);

    $status = wp_remote_retrieve_response_code($response);

    return $status === 200;
  }
}


if (!function_exists('sndech_nc_sendeach_get_api_key')) {
  /**
   * Get API Key
   * 
   * @return string
   */
  function sndech_nc_sendeach_get_api_key()
  {
    $settings = get_option('sendeach_settings');
    $is_admin_key = isset($settings['use_admin_api_key']) ? $settings['use_admin_api_key'] : false;

    if ($is_admin_key) {
      return '';//return "163|BNKTDqmgWy6C1Tcl8P3MtYVAWbdNXTBqGUBnOrDz";
    }

    return isset($settings['api_key']) ? $settings['api_key'] : '';
  }
}
