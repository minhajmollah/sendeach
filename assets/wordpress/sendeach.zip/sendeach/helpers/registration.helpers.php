<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!function_exists('sndech_nc_validate_user')) {
  /**
   * Validate user
   * 
   * @param string $username
   * @param string $email
   * @param string $whatsapp_number
   * 
   * @return array|true
   */
  function sndech_nc_validate_user($username, $email, $whatsapp_number)
  {
    $error = [];

    // find user by username
    $user_by_username = get_user_by('login', $username);

    if ($user_by_username) {
      $error['username'] = 'Username already exists';
      return $error;
    }

    // find user by email
    $user_by_email = get_user_by('email', $email);

    if ($user_by_email) {
      $error['email'] = 'Email already exists';
      return $error;
    }

    // find user by phone
    $user_by_phone = get_users(array(
      'meta_key' => '_sendeach_whatsapp_number',
      'meta_value' => $whatsapp_number,
      'meta_compare' => '='
    ));

    if ($user_by_phone) {
      $error['whatsapp_number'] = 'Phone already exists';
      return $error;
    }

    return true;
  }
}
