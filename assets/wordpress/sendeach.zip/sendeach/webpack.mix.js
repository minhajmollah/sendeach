/** @format */

const { readFileSync, existsSync, mkdirSync, rmdirSync } = require("fs");
const { copySync } = require("fs-extra");
const { zip } = require("zip-a-folder");
const mix = require("laravel-mix");
const { join } = require("path");
const os = require("os");

require("mix-env-file");

// set env file
if (existsSync(join(__dirname, ".env"))) {
  mix.env(join(__dirname, ".env"));

  console.log("Env file loaded");
}

// plugin directory name
const pluginDirName = __dirname
  .replace(/(\/|\\)+/g, "/")
  .split("/")
  .pop();

mix
  // scss files
  // .sass(join("src", "scss", "app.scss"), join("css"))

  // js files
  .ts(join("src", "js", "login-registration-form.tsx"), join("js"))
  .ts(join("src", "js", "sendeach-settings.ts"), join("js"))

  .react()

  // create websocket server for hot reload
  .browserSync({
    proxy: "http://wordpress.test",
    files: [
      "assets/css/**/*.css",
      "templates/**/*.php",
      "assets/js/**/*.js",
      "assets/imgs/**/*",
    ],
    watch: true,
    open: true,
  })

  // set where assets will be exported
  .setResourceRoot(join("/", "wp-content", "plugins", pluginDirName, "assets"))

  // set public path
  .setPublicPath(join("assets"))

  // save files from cache
  .webpackConfig({
    cache: {
      type: "filesystem",
    },
  })

  // zip the plugin after build is done
  .after(async (webpackStats) => {
    if (mix.inProduction()) {
      const pkg = readFileSync(join(__dirname, "package.json"), "utf8");
      const json = JSON.parse(pkg);
      const dirName = join(os.tmpdir(), json.name);

      try {
        if (existsSync(dirName)) {
          rmdirSync(dirName, { recursive: true });
        }

        mkdirSync(dirName);

        const files = [
          // directories
          "dependencies",
          "abstracts",
          "templates",
          "classes",
          "helpers",
          "assets",
          "vendor",
          "hooks",
          "lang",
          // "src",

          // files
          "generate-mo-files.sh",
          "generate-po-files.sh",
          "webpack.mix.js",
          "composer.json",
          "package.json",
          ".gitignore",
          "index.php",
        ];

        files.forEach((dir) => {
          if (existsSync(join(__dirname, dir))) {
            copySync(join(__dirname, dir), join(dirName, dir));
          }
        });

        await zip(dirName, join(__dirname, json.name + ".zip"));
      } catch (e) {
        console.log("Failed to pack the plugin");
      }

      rmdirSync(dirName, { recursive: true });
    }
  });
