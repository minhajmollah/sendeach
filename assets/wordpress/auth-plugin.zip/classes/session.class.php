<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('NC_Session_Manager')) {
  /**
   * Session manager class
   */
  class NC_Session_Manager
  {
    private $cookie_name = 'nc_user_session_';
    public static $insance = null;
    public $session_id = null;
    public $data = [];

    /**
     * Constructor
     */
    public function __construct()
    {
      $cookie_name = $this->cookie_name . 'id';
      $this->session_id = isset($_COOKIE[$cookie_name]) ? $_COOKIE[$cookie_name] : null;

      if ($this->session_id == null) {
        // Create a new session cookie
        $this->create_session();
      }

      $this->load_session_data();
    }

    /**
     * Create a new session
     */
    public function create_session()
    {
      $this->session_id = uniqid($this->cookie_name, true);
      $expiry_time = time() + (DAY_IN_SECONDS * 30); // DAY_IN_SECONDS = 1 day
      setcookie($this->cookie_name . 'id', $this->session_id, $expiry_time, '/');
      setcookie($this->cookie_name . 'expiry', $expiry_time, $expiry_time, '/');
    }

    /**
     * Get instance
     * 
     * @return NC_Session_Manager
     */
    public static function get_instance()
    {
      if (self::$insance == null) {
        self::$insance = new self();
      }

      return self::$insance;
    }

    /**
     * Load session data
     */
    public function load_session_data()
    {
      // use transient api to store session data
      $this->data = get_transient($this->session_id);

      if ($this->data == false) {
        $this->data = [];
      }

      return $this->data;
    }

    /**
     * Destroy session
     */
    public function destroy()
    {
      $this->data = [];
      delete_transient($this->session_id);
    }

    /**
     * Set session data
     * 
     * @param string $key
     * @param mixed $value
     * @return NC_Session_Manager
     */
    public function set($key, $value)
    {
      // Split the dot-separated keys into an array.
      $keys = explode('.', $key);

      // Start with the top-level array.
      $data = &$this->data;

      // Traverse the array using each key in the $keys array.
      foreach ($keys as $innerKey) {
        // If $data is not an array, initialize it to an empty array.
        if (!is_array($data)) {
          $data = [];
        }
        // Set the reference to the inner array.
        $data = &$data[$innerKey];
      }

      // Set the final value in the nested array.
      $data = $value;

      return $this;
    }

    /**
     * Get session data
     * 
     * @param string $path
     * @return mixed
     */
    public function get($path, $default = null)
    {
      $keys = explode('.', $path);

      $data = $this->data;

      foreach ($keys as $key) {
        if (!isset($data[$key])) {
          return $default;
        }

        $data = $data[$key];
      }

      return $data;
    }

    /**
     * Delete session data
     * 
     * @param string $key
     * @return NC_Session_Manager
     */
    public function delete($key)
    {
      unset($this->data[$key]);

      return $this;
    }

    /**
     * Save session data
     * 
     * @param number $expiry
     * @return void
     */
    public function save($expiry = 7 * DAY_IN_SECONDS)
    {
      set_transient($this->session_id, $this->data, $expiry);
    }
  }
}
