<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('NC_Init')) {
  class NC_Init
  {
    protected $hooks_classnames_list = [];
    protected $plugin_dir = null;

    /**
     * Add hooks classnames to list
     * 
     * @param string[] $hooks_classnames_list Hooks classnames list
     * @return NC_Init $this
     */
    final public function add_hooks_classnames($hooks_classnames_list)
    {
      $this->hooks_classnames_list = array_merge($this->hooks_classnames_list, $hooks_classnames_list);
      return $this;
    }

    /**
     * Set plugin directory
     * 
     * @param string $dir Plugin directory
     * @return NC_Init $this
     */
    final public function set_plugin_dir(string $dir)
    {
      if (!is_dir($dir)) {
        throw new Exception("Plugin directory not found");
      }

      $this->plugin_dir = realpath($dir);
      return $this;
    }

    /**
     * Execute hooks
     * 
     * @return void
     */
    final public function execute()
    {
      foreach ($this->hooks_classnames_list as $classname) {
        if (class_exists($classname) && is_a($classname, 'NC_Hooks', true)) {
          $instance = new $classname();
          $instance->__init($this->plugin_dir);
        }
      }
    }
  }
}
