<?php

/**
 * Plugin Name: Sendeach
 * Description: Sendeach wordpress plugin
 * Version: 1.2.0
 * Author: Sendeach
 * Author URI: http://Sendeach.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: sendeach
 * Domain Path: /lang
 * Requires at least: 5.0
 * Tested up to: 5.5
 * Requires PHP: 7.2
 */

if (!defined('ABSPATH')) {
  exit;
}

if (file_exists(__DIR__ . "/vendor/autoload.php")) {
  include __DIR__ . "/vendor/autoload.php";
}

$directories = [
  "helpers" => "*.helpers.php",
  "abstracts" => "*.abstract.php",
  "classes" => "*.class.php",
  "hooks" => "*.hooks.php"
];

foreach ($directories as $dir => $pattern) {
  foreach (glob(__DIR__ . "/{$dir}/{$pattern}") as $filename) include $filename;
}

$instance = new NC_Init;

$instance->add_hooks_classnames([
  NC_Login_Registration_Hooks::class,
  NC_Settings_Hooks::class,
]);

$instance->set_plugin_dir(plugin_dir_path(__FILE__));
$instance->execute();
