<?php

if (!defined('ABSPATH')) {
  exit;
}

?>

<!-- admin settings page -->
<div class="wrap">
  <h1>
    <img src="<?php echo $this->get_asset_url('imgs/sendeach-logo.png'); ?>" height="50" width="auto" alt="SendEach" />
  </h1>

  <!-- form and sections -->
  <form action="options.php" method="post">
    <?php settings_fields('sendeach_settings'); ?>
    <?php do_settings_sections('sendeach'); ?>

    <!-- submit button -->
    <?php submit_button(); ?>
  </form>
</div>