<?php

use Respect\Validation\Exceptions\EmailException;
use Respect\Validation\Exceptions\EqualsException;
use Respect\Validation\Exceptions\LengthException;
use Respect\Validation\Exceptions\NestedValidationException;
use Respect\Validation\Exceptions\NotEmptyException;
use Respect\Validation\Exceptions\PhoneException;
use Respect\Validation\Validator as v;

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('NC_Login_Registration_Hooks')) {
  class NC_Login_Registration_Hooks extends NC_Hooks
  {
    public function admin_hooks()
    {
    }

    public function public_hooks()
    {
    }

    public function common_hooks()
    {
      // add login/register form shortcode
      add_shortcode('nc_login_registration_form', array($this, 'nc_login_registration_form'));

      // enqueue scripts
      add_action('wp_enqueue_scripts', array($this, 'nc_enqueue_scripts'));
      add_action('wp_footer', array($this, 'nc_foot'));

      // handle login
      add_action('wp_ajax_nc_login_registration_login', array($this, 'nc_login_registration_login'));
      add_action('wp_ajax_nopriv_nc_login_registration_login', array($this, 'nc_login_registration_login'));

      // handle register
      add_action('wp_ajax_nc_login_registration_register', array($this, 'nc_login_registration_register'));
      add_action('wp_ajax_nopriv_nc_login_registration_register', array($this, 'nc_login_registration_register'));

      // manipulate the page content
      //add_filter('the_content', [$this, 'nc_manipulate_the_content'], 99);
    }

    /**
     * Login/Register form shortcode
     *
     * @param array $atts
     * @return string
     */
    public function nc_foot(){
      ?>
      <script type="text/javascript">
        jQuery( document ).ready(function() {
            console.log( "ready!" );
            jQuery('.MuiButton-root').css("background-color","blue")
        });
        
      </script>
      <?php
    }
    public function nc_login_registration_form($atts)
    {
      ob_start();
      $settings = get_option('sendeach_settings');
      $terms_and_conditions_page = null;
      $sendeach_login_form_title = null;
      $sendeach_register_form_title = null;
      $register_page = null;
      $login_page = null;
      $btn_background=null;
      $btn_text=null;
      $btn_hover_background=null;

      $redirect = is_user_logged_in();

      if (isset($_GET['elementor-preview']) || is_admin()) {
        $redirect = false;
      }

      $ss=get_user_meta(166);
      
      if ($redirect) {
        if ($settings['sendeach_redirect_url']) {
            $redirect_url=$settings['sendeach_redirect_url'];
        }else{
          $redirect_url=home_url();
        }
        ?>
        <script type="text/javascript">
          window.location.href='<?php echo $redirect_url; ?>'
        </script>
        <?php
        wp_safe_redirect(home_url());
        exit;
      }else{
        if (isset($settings['sendeach_login_page'])) {
          $login_page = (int) $settings['sendeach_login_page'];
        }

        if (isset($settings['sendeach_register_page'])) {
          $register_page = (int) $settings['sendeach_register_page'];
        }

        if (isset($settings['sendeach_terms_and_conditions_page'])) {
          $terms_and_conditions_page = (int) $settings['sendeach_terms_and_conditions_page'];
        }

        if (isset($settings['sendeach_login_form_title'])) {
          $sendeach_login_form_title = $settings['sendeach_login_form_title'];
        }

        if (isset($settings['sendeach_register_form_title'])) {
          $sendeach_register_form_title = $settings['sendeach_register_form_title'];
        }

        if (isset($settings['btn_background'])) {
          $btn_background = $settings['btn_background'];
        }

        if (isset($settings['btn_text'])) {
          $btn_text = $settings['btn_text'];
        }

        if (isset($settings['btn_hover_background'])) {
          $btn_hover_background = $settings['btn_hover_background'];
        }

        $atts = shortcode_atts(array(
          // type = login | register | both
          'type' => 'login',
          'login_form_url' => get_permalink($login_page),
          'register_form_url' => get_permalink($register_page),
          'terms_and_conditions_page' => get_permalink($terms_and_conditions_page),
          'login_form_title' => $sendeach_login_form_title ?: 'Login',
          'register_form_title' => $sendeach_register_form_title ?: 'Register',
          'btn_background' => $btn_background ?: '#000000',
          'btn_text' => $btn_text ?: '#ffffff',
          'btn_hover_background' => $btn_hover_background ?: '#eeeeee',
        ), $atts);

        if (!in_array($atts['type'], array('login', 'register', 'both'))) {
          $atts['type'] = 'both';
        }

        if (isset($_GET['type']) && in_array($_GET['type'], array('login', 'register'))) {
          $atts['type'] = $_GET['type'];
        }
        $html = '<div class="nc-login-registration-form-wrapper"';
        $html .= ' data-type="' . $atts['type'] . '"';
        $html .= ' data-login-form-url="' . $atts['login_form_url'] . '"';
        $html .= ' data-register-form-url="' . $atts['register_form_url'] . '"';
        $html .= ' data-terms-and-conditions-page="' . $atts['terms_and_conditions_page'] . '"';
        $html .= ' data-login-form-title="' . $atts['login_form_title'] . '"';
        $html .= ' data-register-form-title="' . $atts['register_form_title'] . '"';
        $html .= ' data-register-form-btn-background="' . $atts['btn_background'] . '"';
        $html .= ' data-register-form-btn-text="' . $atts['btn_text'] . '"';
        $html .= ' data-register-form-btn-hover-background="' . $atts['btn_hover_background'] . '"';
        $html .= ' ></div>';
        echo $html;
        //return $html;
        $ReturnString = ob_get_contents(); ob_end_clean(); 
        return $ReturnString;
      }
      
    }

    /**
     * Enqueue scripts
     *
     * @return void
     */
    public function nc_enqueue_scripts()
    {
      global $post;

      if (!$post) return;

      $settings = get_option('sendeach_settings');

      $allowed_pages = [];

      if (isset($settings['sendeach_login_page'])) {
        $allowed_pages[] = (int) $settings['sendeach_login_page'];
      }

      if (isset($settings['sendeach_register_page'])) {
        $allowed_pages[] = (int) $settings['sendeach_register_page'];
      }


      // if (!$post || !in_array($post->ID, $allowed_pages)) {
      //   return;
      // }

      wp_enqueue_script('nc-login-registration', $this->get_asset_url('js/login-registration-form.js'), array('jquery'), '1.0.0', true);

      $params = [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('nc-login-registration-nonce'),
        'form_url' => get_permalink(),
        'post_id' => get_the_ID(),
        'login_action' => 'nc_login_registration_login',
        'register_action' => 'nc_login_registration_register',
        'is_user_logged_in' => is_user_logged_in(),
        'logout_url' => wp_logout_url(home_url()),
      ];

      wp_localize_script('nc-login-registration', 'nc_login_registration_params', $params);
    }

    /**
     * Handle register
     *
     * @return void
     */
    public function nc_login_registration_register()
    {
      try {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        $settings = get_option('sendeach_settings');
        $otp_sms = isset($settings['sms']) ? $settings['sms'] : '0';
        $otp_whatsapp = isset($settings['whatsapp']) ? $settings['whatsapp'] : '0';
        $otp_email = isset($settings['email']) ? $settings['email'] : '0';
        $use_admin_api_key = isset($settings['use_admin_api_key']) ? $settings['use_admin_api_key'] : '0';

        $validation = v::keySet(
          v::key('username', v::stringType()->notEmpty()),
          v::key('email', v::email()),
          v::key('whatsapp_number', v::phone()),
          v::key('password', v::stringType()->notEmpty()->length(8, null)),
          v::key('confirm_password', v::equals(isset($data['password']) ? $data['password'] : null)),
          v::key('otp', v::stringType(), false)
        );

        try {
          $validation->check($data);
        } catch (Throwable $e) {
          $field_name = $e->getParam('name');

          if ($e instanceof EqualsException) {
            $e->updateTemplate('The "Confirm Password" field must be equal to the "Password" field.');
          } else if ($e instanceof LengthException) {
            $e->updateTemplate('The "Password" field must be at least 8 characters.');
          } else if ($e instanceof PhoneException) {
            $e->updateTemplate('The "Whatsapp Number" field must be a valid phone number.');
          } else if ($e instanceof NotEmptyException) {
            switch ($field_name) {
              case 'username':
                $e->updateTemplate('The "Username" field is required.');
                break;
              case 'name':
                $e->updateTemplate('The "Name" field is required.');
                break;
              case 'email':
                $e->updateTemplate('The "Email" field is required.');
                break;
              case 'password':
                $e->updateTemplate('The "Password" field is required.');
                break;
              case 'confirm_password':
                $e->updateTemplate('The "Confirm Password" field is required.');
                break;
            }
          } else if ($e instanceof EmailException) {
            $e->updateTemplate('The "Email" field must be a valid email address.');
          } else if ($e instanceof LengthException) {
            $e->updateTemplate('The "Password" field must be at least 8 characters.');
          } else {
            wp_send_json(['global' => __('Something went wrong, please try again later.', 'sendeach')], 422);
          }

          wp_send_json([$field_name => $e->getMessage()], 422);
        }

        // check if username is valid using built in wordpress function
        $is_valid_username = validate_username($data['username']);
        if ($is_valid_username !== true) {
          wp_send_json(['username' => $is_valid_username], 422);
        }

        // check if user already exists using email or whatsapp number or username
        $is_valid_user = nc_validate_user($data['username'], $data['email'], $data['whatsapp_number']);

        if (is_array($is_valid_user)) {
          wp_send_json($is_valid_user, 422);
        }

        if (isset($data['otp']) && $data['otp']) {
          $otp_code = (int) $data['otp'];
          $otp_code_from_session = nc_session()->get('user_registration_data.otp.code');
          $otp_expired_at = nc_session()->get('user_registration_data.otp.expired_at');
          $email = nc_session()->get('user_registration_data.email');
          $whatsapp_number = nc_session()->get('user_registration_data.whatsapp_number');
          $username = nc_session()->get('user_registration_data.username');
          $password = nc_session()->get('user_registration_data.password');

          // check if otp code is valid
          if ($otp_code !== $otp_code_from_session) {
            wp_send_json(['otp' => 'Invalid OTP code.'], 422);
          }

          // check if otp code is expired
          if (time() > $otp_expired_at) {
            wp_send_json(['otp' => 'OTP code has expired.'], 422);
          }

          // create user
          $user_id = wp_create_user($username, $password, $email);

          add_user_meta($user_id, '_sendeach_whatsapp_number', $whatsapp_number, true);

          // login user
          wp_set_current_user($user_id);
          wp_set_auth_cookie($user_id);
          do_action('wp_login', $username, get_userdata($user_id));

          // delete session
          nc_session()->delete('user_registration_data')->save();

          wp_send_json(['redirect_url' => home_url()], 200);
        }

        $otp_code = rand(100000, 999999);

        $website_title = get_bloginfo('name');
        $message = "Your OTP code is {$otp_code}, valid for 5 minutes.\n\nPlease enter the code to complete your registration on {$website_title}.";

        if ($otp_whatsapp){
          if ($use_admin_api_key) {
            $sent = nc_sendeach_send_admin_whatsapp_message($data['whatsapp_number'], $otp_code);  
            $otp_sent[]='whatsapp_admin';
          }else{
            $sent = nc_sendeach_send_whatsapp_message($data['whatsapp_number'], $message);  

            $otp_sent[]='whatsapp';
          }
          
        }
        if ($otp_sms){
          $sent = nc_sendeach_send_sms_message($data['whatsapp_number'], $message);
          $otp_sent[]='sms';
        }
        if ($otp_email){
          if ($use_admin_api_key) {
            $sent = nc_sendeach_send_admin_email_message($data['email'], $otp_code); 
            $otp_sent[]='email_admin';
          }else{
            $sent = nc_sendeach_send_email_message($data['email'], $message); 
            $otp_sent[]='email';
          }
          
        }

        if (!$sent) {
          wp_send_json(['whatsapp_number' => 'Failed to send OTP code.'], 422);
        }

        nc_session()->set('user_registration_data', $data)
          ->set('user_registration_data.otp.code', $otp_code)
          ->set('user_registration_data.otp.expired_at', time() + 60 * 5)
          ->save();

        wp_send_json(['screen' => 'otp','otp_sent'=>$otp_sent], 200);

      } catch (Throwable $e) {
        dd($e);
      }
    }

    /**
     * Handle login
     *
     * @return void
     */
    public function _v1_nc_login_registration_login()
    {
      $json = file_get_contents('php://input');
      $data = json_decode($json, true);

      $validation = v::keySet(
        v::key('email', v::email()),
        v::key('password', v::stringType()->notEmpty()),
        v::key('remember', v::boolVal(), false),
        v::key('otp', v::stringType(), false)
      );

      try {
        $validation->check($data);
      } catch (NestedValidationException $e) {
        $field_name = $e->getParam('name');

        if ($e instanceof NotEmptyException) {
          switch ($field_name) {
            case 'email':
              $e->updateTemplate('The "Email" field is required.');
              break;
            case 'password':
              $e->updateTemplate('The "Password" field is required.');
              break;
          }
        } else if ($e instanceof EmailException) {
          $e->updateTemplate('The "Email" field must be a valid email address.');
        }

        wp_send_json([$field_name => $e->getMessage()], 422);
      }

      $user = get_user_by('email', $data['email']);

      if (!$user) {
        wp_send_json(['global' => 'Invalid email or password.'], 422);
      }

      // check if password is valid
      $is_valid_password = wp_check_password($data['password'], $user->data->user_pass, $user->ID);
      if (!$is_valid_password) {
        wp_send_json(['global' => 'Invalid email or password.'], 422);
      }

      $whatsapp_number = get_user_meta($user->ID, '_sendeach_whatsapp_number', true);
      $remember = isset($data['remember']) ? $data['remember'] : '0';

      if (!$whatsapp_number) {
        // login user
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);
        do_action('wp_login', $user->user_login, get_userdata($user->ID));

        wp_send_json(['redirect_url' => home_url()], 200);
      }

      if (isset($data['otp']) && $data['otp']) {
        $otp_code = (int) $data['otp'];
        $otp_code_from_session = nc_session()->get('user_login_data.otp.code');
        $otp_expired_at = nc_session()->get('user_login_data.otp.expired_at');

        // check if otp code is valid
        if ($otp_code !== $otp_code_from_session) {
          wp_send_json(['otp' => 'Invalid OTP code.'], 422);
        }

        // check if otp code is expired
        if (time() > $otp_expired_at) {
          wp_send_json(['otp' => 'OTP code has expired.'], 422);
        }

        // login user
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);
        do_action('wp_login', $user->user_login, get_userdata($user->ID));

        wp_send_json(['redirect_url' => home_url()], 200);
      }

      $otp_code = rand(100000, 999999);
      $website_title = get_bloginfo('name');
      $message = "Your OTP code is {$otp_code}, valid for 5 minutes.\n\nPlease enter the code to complete your login on {$website_title}.";

      $sent = nc_sendeach_send_whatsapp_message($whatsapp_number, $message);

      if (!$sent) {
        wp_send_json(['global' => 'Failed to send OTP code.'], 422);
      }

      nc_session()->set('user_login_data', $data)
        ->set('user_login_data.otp.code', $otp_code)
        ->set('user_login_data.otp.expired_at', time() + 60 * 5)
        ->save();

      wp_send_json(['screen' => 'otp'], 200);
    }

    /**
     * Handle login
     *
     * @return void
     */
    public function nc_login_registration_login()
    {
      $json = file_get_contents('php://input');
      $data = json_decode($json, true);
      $settings = get_option('sendeach_settings');
      $otp_sms = isset($settings['sms']) ? $settings['sms'] : '0';
      $otp_whatsapp = isset($settings['whatsapp']) ? $settings['whatsapp'] : '0';
      $otp_email = isset($settings['email']) ? $settings['email'] : '0';
      $use_admin_api_key = isset($settings['use_admin_api_key']) ? $settings['use_admin_api_key'] : '0';
      

      $validation = v::keySet(
        v::key('whatsapp_number', v::phone()),
        v::key('remember', v::boolVal(), false),
        v::key('otp', v::stringType(), false)
      );

      try {
        $validation->check($data);
      } catch (NestedValidationException $e) {
        $field_name = $e->getParam('name');

        if ($e instanceof PhoneException) {
          $e->updateTemplate('The "WhatsApp Number" field must be a valid phone number.');
        }

        wp_send_json([$field_name => $e->getMessage()], 422);
      }

      $remember = isset($data['remember']) ? $data['remember'] : '0';
      $whatsapp_number = $data['whatsapp_number'];
      $user_email = $data['user_email'];

      $users = get_users([
        'meta_key' => '_sendeach_whatsapp_number',
        'meta_value' => $data['whatsapp_number'],
        'number' => 1,
        'count_total' => false
      ]);

      $user = null;

      if (count($users) > 0) {
        $user = $users[0];
      } else {
        wp_send_json(['whatsapp_number' => 'No user found with this WhatsApp number.'], 422);
      }

      if (isset($data['otp']) && $data['otp']) {
        $otp_code = (int) $data['otp'];
        $otp_code_from_session = nc_session()->get('user_login_data.otp.code');
        $otp_expired_at = nc_session()->get('user_login_data.otp.expired_at');

        // check if otp code is valid
        if ($otp_code !== $otp_code_from_session) {
          wp_send_json(['otp' => 'Invalid OTP code.'], 422);
        }

        // check if otp code is expired
        if (time() > $otp_expired_at) {
          wp_send_json(['otp' => 'OTP code has expired.'], 422);
        }

        // login user
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, $remember);
        do_action('wp_login', $user->user_login, get_userdata($user->ID));

        wp_send_json(['redirect_url' => home_url()], 200);
      }

      $otp_code = rand(100000, 999999);
      $website_title = get_bloginfo('name');
      $message = "Your OTP code is {$otp_code}, valid for 5 minutes.\n\nPlease enter the code to complete your login on {$website_title}.";

        if ($otp_whatsapp){
          if ($use_admin_api_key) {
            $sent = nc_sendeach_send_admin_whatsapp_message($whatsapp_number, $otp_code);  
            $otp_sent[]='whatsapp_admin';
          }else{
            $sent = nc_sendeach_send_whatsapp_message($whatsapp_number, $message);  
            $otp_sent[]='whatsapp';
          }
          
        }
        if ($otp_sms){
          $sent = nc_sendeach_send_sms_message($whatsapp_number, $message);
          $otp_sent[]='sms';
        }


      
      if (!$sent) {
        wp_send_json(['global' => 'Failed to send OTP code.'], 422);
      }

      nc_session()->set('user_login_data', $data)
        ->set('user_login_data.otp.code', $otp_code)
        ->set('user_login_data.otp.expired_at', time() + 60 * 5)
        ->save();

      wp_send_json(['screen' => 'otp'], 200);

    }

    /**
     * Manipulate page content
     */
    public function nc_manipulate_the_content($content)
    {
      global $post;

      $settings = get_option('sendeach_settings');
      $login_input_form = isset($settings['sendeach_input_login_form']) ? $settings['sendeach_input_login_form'] : '1';
      $register_input_form = isset($settings['sendeach_input_register_form']) ? $settings['sendeach_input_register_form'] : '1';

      if (isset($settings['sendeach_login_page']) && $settings['sendeach_login_page'] == $post->ID && $login_input_form) {
        $content = do_shortcode('[nc_login_registration_form type="login"]');
      }

      if (isset($settings['sendeach_register_page']) && $settings['sendeach_register_page'] == $post->ID && $register_input_form) {
        $content = do_shortcode('[nc_login_registration_form type="register"]');
      }

      return $content;
    }
  }
}
