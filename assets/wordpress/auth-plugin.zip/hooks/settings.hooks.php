<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('NC_Settings_Hooks')) {
  class NC_Settings_Hooks extends NC_Hooks
  {
    public function admin_hooks()
    {
      // add menu page
      add_action('admin_menu', [$this, 'add_menu_page']);

      // register settings
      add_action('admin_init', [$this, 'register_settings']);

      // enqueue scripts
      add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
      
    }

    public function public_hooks()
    {
    }

    public function common_hooks()
    {

    }

    public function cn_update($input) {
      $settings = get_option('sendeach_settings');

      $login_page_id = isset($settings['sendeach_login_page']) ? $settings['sendeach_login_page'] : '';
      $register_page_id = isset($settings['sendeach_register_page']) ? $settings['sendeach_register_page'] : '';
      $sendeach_input_login_form = isset($settings['sendeach_input_login_form']) ? $settings['sendeach_input_login_form'] : '';
      $sendeach_input_register_form = isset($settings['sendeach_input_register_form']) ? $settings['sendeach_input_register_form'] : '';
      if ($input['sendeach_input_login_form']) {
        // if ($sendeach_input_login_form) {
        // }else{
          
            $login_page_id=$input['sendeach_login_page'];
          
          $data = array(
            'ID' => $login_page_id,
            'post_content' =>'[nc_login_registration_form type="login"]',
           );
          wp_update_post($data);
        //}
      }
      if ($input['sendeach_input_register_form']) {
        /*if ($sendeach_input_register_form) {
        }else{*/
           
          $register_page_id=$input['sendeach_register_page'];
          
          $data = array(
            'ID' => $register_page_id,
            'post_content' =>'[nc_login_registration_form type="register"]',
           );
          wp_update_post( $data );
        //}

      }
      return $input;
    }

    
    /*
    * Add menu page
    */
    public function add_menu_page()
    {
      add_menu_page(
        __('SendEach', 'sendeach'),
        __('SendEach', 'sendeach'),
        'manage_options',
        'sendeach',
        [$this, 'render_menu_page'],
        'dashicons-email-alt',
        6
      );
    }

    /**
     * Render menu page
     */
    public function render_menu_page()
    {
      $this->load_template('admin/settings');
    }

    /**
     * Register settings
     */
    public function register_settings()
    {
      register_setting('sendeach_settings', 'sendeach_settings', [
        'type' => 'array',
        'sanitize_callback'=>[$this,'cn_update'],
      ]);

      // register section for API Key
      add_settings_section(
        'sendeach_api_key_section',
        __('Authentication', 'sendeach'),
        [$this, 'render_api_key_section'],
        'sendeach'
      );

      //register field for checkbox to use admin api key or custom api key
      add_settings_field(
        'sendeach_use_admin_api_key',
        __('Use admin API Key', 'sendeach'),
        [$this, 'render_use_admin_api_key_field'],
        'sendeach',
        'sendeach_api_key_section'
      );

      // register field for API Key
      add_settings_field(
        'sendeach_api_key',
        __('API Key', 'sendeach'),
        [$this, 'render_api_key_field'],
        'sendeach',
        'sendeach_api_key_section'
      );

      // pick pages section
      add_settings_section(
        'sendeach_pick_pages_section',
        __('Select pages', 'sendeach'),
        [$this, 'render_pick_pages_section'],
        'sendeach',
      );

      // pick login form page
      add_settings_field(
        'sendeach_pick_login_page',
        __('Login page', 'sendeach'),
        [$this, 'render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_login_page',
        ]
      );

      // input form
      add_settings_field(
        'sendeach_pick_input_page',
        __('Input Login Form in page', 'sendeach'),
        [$this, 'render_pick_page_input_login_form_field'],
        'sendeach',
        'sendeach_pick_pages_section'
      );

      // pick register form page
      add_settings_field(
        'sendeach_pick_register_page',
        __('Register page', 'sendeach'),
        [$this, 'render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_register_page',
        ]
      );

      // input register form
      add_settings_field(
        'sendeach_pick_input_register_page',
        __('Input Register Form in page', 'sendeach'),
        [$this, 'render_pick_page_input_register_form_field'],
        'sendeach',
        'sendeach_pick_pages_section'
      );

      // pick terms and conditions page
      add_settings_field(
        'sendeach_pick_terms_and_conditions_page',
        __('Terms and conditions page', 'sendeach'),
        [$this, 'render_pick_page_select_field'],
        'sendeach',
        'sendeach_pick_pages_section',
        [
          'id' => 'sendeach_terms_and_conditions_page',
        ]
      );
      add_settings_field(
        'sendeach_redirect_url',
        __('Redirect url', 'sendeach'),
        [$this, 'render_redirect_url'],
        'sendeach',
        'sendeach_pick_pages_section',
      );

      // OTP protocol
      add_settings_section(
        'sendeach_otp_protocol_section',
        __('OTP Protocol', 'sendeach'),
        [$this, 'render_otp_section'],
        'sendeach',
      );

      //input form
      add_settings_field(
        'sendeach_pick_input_page',
        __('Input Login Form in page', 'sendeach'),
        [$this, 'render_otp_protocol'],
        'sendeach',
        'sendeach_otp_protocol_section'
      );

      // Forms titles section
      add_settings_section(
        'sendeach_forms_titles_section',
        __('Forms titles', 'sendeach'),
        [$this, 'render_forms_titles_section'],
        'sendeach',
      );

      // Login form title
      add_settings_field(
        'sendeach_login_form_title',
        __('Login form title', 'sendeach'),
        [$this, 'render_forms_titles_field'],
        'sendeach',
        'sendeach_forms_titles_section',
        [
          'id' => 'sendeach_login_form_title',
          'default' => 'Login'
        ]
      );

      // Register form title
      add_settings_field(
        'sendeach_register_form_title',
        __('Register form title', 'sendeach'),
        [$this, 'render_forms_titles_field'],
        'sendeach',
        'sendeach_forms_titles_section',
        [
          'id' => 'sendeach_register_form_title',
          'default' => 'Register'
        ]
      );
      //Register form shortcode
      add_settings_field(
        'sendeach_button_color',
        __('Change color of button', 'sendeach'),
        [$this, 'render_button_color'],
        'sendeach',
        'sendeach_forms_titles_section',
        
      );
      // Login form shortcode
      // add_settings_field(
      //   'sendeach_login_form_shortcode',
      //   __('Login form Shortcode', 'sendeach'),
      //   [$this, 'render_login_form_shortcode'],
      //   'sendeach',
      //   'sendeach_forms_titles_section',
        
      // );

      // add support section
      add_settings_section(
        'sendeach_support_section',
        __('Support', 'sendeach'),
        [$this, 'render_support_section'],
        'sendeach'
      );

      // add support link field
      add_settings_field(
        'sendeach_support_link',
        __('Support link', 'sendeach'),
        [$this, 'render_support_link_field'],
        'sendeach',
        'sendeach_support_section'
      );
    }

    /**
     * Render API Key section
     */
    public function render_api_key_section()
    {
      echo '<span id="sendeach_api_key_section_description" style="display: none;">' . __('Enter your API Key to authenticate with SendEach', 'sendeach') . '</span>';
    }

    /**
     * Render API Key field
     */
    public function render_api_key_field()
    {
      $settings = get_option('sendeach_settings');
      $api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
      $url = "https://sendeach.com/docs/api-tokens";
      echo '<input type="text" name="sendeach_settings[api_key]" value="' . $api_key . '" /><br>';
      echo '<a style="margin-top: 5px;" class="button button-primary-alt" href="' . $url . '" target="_blank">' . __('Get API KEY', 'sendeach') . '</a>';
    }

    /**
     * Render checkbox to use admin api key or custom api key
     */
    public function render_use_admin_api_key_field()
    {
      $settings = get_option('sendeach_settings');

      $use_admin_api_key = isset($settings['use_admin_api_key']) ? $settings['use_admin_api_key'] : '';

      echo '<input type="checkbox" name="sendeach_settings[use_admin_api_key]" value="1" ' . checked(1, $use_admin_api_key, false) . ' />';
    }

    /**
     * Enqueue scripts
     */
    public function enqueue_scripts()
    {
      // check if we are on the right page
      if (get_current_screen()->id !== 'toplevel_page_sendeach') {
        return;
      }

      // enqueue scripts
      wp_enqueue_script('sendeach-admin', $this->get_asset_url('js/sendeach-settings.js'), ['jquery'], '1.0.0', true);
    }

    /**
     * Render pick pages section
     */
    public function render_pick_pages_section()
    {
      echo __('Select pages to use for login, register and terms and conditions', 'sendeach');
    }

    /**
     * Render pick page select section
     */
    public function render_pick_page_select_field($args)
    {
      $id = $args['id'];
      $value = get_option('sendeach_settings');
      $page_id = isset($value[$id]) ? $value[$id] : '';

      $pages = get_pages();
      if ($id=='sendeach_login_page' OR $id=='sendeach_register_page') {
        $att_required="required";
      }else{
        $att_required='';
      }
      echo '<select name="sendeach_settings[' . $id . ']" '.$att_required.'>';
      echo '<option value="">' . __('Select page', 'sendeach') . '</option>';

      foreach ($pages as $page) {
        echo '<option value="' . $page->ID . '" ' . selected($page->ID, $page_id, false) . '>' . $page->post_title . '</option>';
      }

      echo '</select>';
      if ($id=='sendeach_register_page') {
        echo '<br>shortcode for Registration page [nc_login_registration_form type="register"]' ;  
      }
      if ($id=='sendeach_login_page') {
        echo '<br>shortcode for login page [nc_login_registration_form type="login"]';
      }
    }
    public function render_redirect_url($args)
    {
      
      $value = get_option('sendeach_settings');
      $sendeach_redirect_url = isset($value['sendeach_redirect_url']) ? $value['sendeach_redirect_url'] : '';
      echo '<input type="text" name="sendeach_settings[sendeach_redirect_url]" value="' . $sendeach_redirect_url . '" /><br>';
      echo '<small>Redirect if user already login</small>';
      
    }

    

    /**
     * Render forms titles section
     */
    public function render_forms_titles_section()
    {
      echo __('Enter forms titles', 'sendeach');
    }

    /**
     * Render forms titles field
     */
    public function render_forms_titles_field($args)
    {
      $id = $args['id'];
      $default = $args['default'];
      $value = get_option('sendeach_settings');
      $title = isset($value[$id]) ? $value[$id] : $default;

      echo '<input type="text" name="sendeach_settings[' . $id . ']" value="' . $title . '" />';
    }
    public function render_button_color()
    {
      $default = $args['default'];
      $value = get_option('sendeach_settings');

      $btn_background = isset($value['btn_background']) ? $value['btn_background'] : '1';
      $btn_text = isset($value['btn_text']) ? $value['btn_text'] : '1';
      $btn_hover_background = isset($value['btn_hover_background']) ? $value['btn_hover_background'] : '1';
      
      echo "<label>Background Color</label><br>";
      echo '<input style="width: 100px;" type="color" name="sendeach_settings[btn_background]" value="' . $btn_background . '" /><br>'; 
      echo "<label>Text Color</label><br>";
      echo '<input style="width: 100px;" type="color" name="sendeach_settings[btn_text]" value="' . $btn_text . '" /><br>'; 
      echo "<label>Hover Background</label><br>";
      echo '<input style="width: 100px;" type="color" name="sendeach_settings[btn_hover_background]" value="' . $btn_hover_background . '" />'; 
    }
    public function render_login_form_shortcode()
    {
      echo '[nc_login_registration_form type="login"]';
    }
    


    /**
     * Render support section
     */
    public function render_support_section()
    {
      $message = "Open ticket to request new features, report and issue, learn more about plugin and API Keys or to donate to developer";
      echo $message;
    }
    public function render_otp_section()
    {
      $message = "";
      echo $message;
    }

    /**
     * Render support link field
     */
    public function render_support_link_field()
    {
      $url = "https://sendeach.com/docs/support";

      echo '<a class="button button-primary-alt" href="' . $url . '" target="_blank">' . __('Contact support', 'sendeach') . '</a>';
    }

    /**
     * input form
     */
    public function render_pick_page_input_login_form_field()
    {
      $value = get_option('sendeach_settings');
      $input_form = isset($value['sendeach_input_login_form']) ? $value['sendeach_input_login_form'] : '1';

      // checkbox
      echo '<input type="hidden" name="sendeach_settings[sendeach_input_login_form]" value="0" />';
      echo '<input type="checkbox" name="sendeach_settings[sendeach_input_login_form]" value="1" ' . checked('1', $input_form, false) . ' /><br>';
      //echo 'if you check this option login shortcode will added automatically on selected login page. all content will be removed from that page during this process. So be carefully';
    }
    /**
     * input OTP protocol
     */
    public function render_otp_protocol()
    {
      $value = get_option('sendeach_settings');
       $whatsapp = isset($value['whatsapp']) ? $value['whatsapp'] : '0';
      $sms = isset($value['sms']) ? $value['sms'] : '0';
      $email = isset($value['email']) ? $value['email'] : '0';

      $api_key = isset($value['use_admin_api_key']) ? $value['use_admin_api_key'] : '0';
      $cn_api_key = isset($value['api_key']) ? $value['api_key'] : '0';
      if ($api_key==0 && $cn_api_key!='') {
        $cn_val=1;
        $cn_val_des='';
      }else{
        $cn_val=0;
        $cn_val_des='disabled';
      }
      echo '<input type="checkbox" name="sendeach_settings[whatsapp]" value="1" ' . checked('1', $whatsapp, false) . ' />Whatsapp <br>';
      echo '<input type="checkbox" name="sendeach_settings[email]" value="1" ' . checked('1', $email, false) . ' />Email <br>';
      echo '<input '.$cn_val_des.' type="checkbox" name="sendeach_settings[sms]" value="1" ' . checked('1', $sms, false) . ' />Sms <br>';
      if ($cn_val_des) {
        echo '<p>for enable sms protocol disable admin api and add your API Key</p>';
      }
      
    }

    /**
     * input register form
     */
    public function render_pick_page_input_register_form_field()
    {
      $value = get_option('sendeach_settings');
      $input_form = isset($value['sendeach_input_register_form']) ? $value['sendeach_input_register_form'] : '1';

      // checkbox
      echo '<input type="hidden" name="sendeach_settings[sendeach_input_register_form]" value="0" />';
      echo '<input type="checkbox" name="sendeach_settings[sendeach_input_register_form]" value="1" ' . checked('1', $input_form, false) . ' /><br>';
      //echo 'if you check this option Registration shortcode will added automatically on selected Registration page. all content will be removed from that page during this process. So be carefully';
    }
  }
}
