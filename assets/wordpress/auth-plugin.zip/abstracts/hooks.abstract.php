<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!class_exists('NC_Hooks')) {
  abstract class NC_Hooks
  {
    public $template_dir = null;
    public $assets_url = null;
    public $plugin_dir = null;
    public $plugin_id = null;

    /**
     * Init hooks
     * 
     * @param string $dir Plugin directory
     * @return void
     */
    final public function __init(string $dir)
    {
      $this->__set_plugin_dir($dir);

      // Initialize the plugin only once
      $initialized = wp_cache_get("__nc_initialized_hooks_list__", "nc") ?: [];

      if (!in_array($this->plugin_id, $initialized)) {
        // load translations
        load_textdomain("sendeach",  realpath($this->plugin_dir . 'lang/' . get_locale() . '.mo'));

        // load dependecies
        add_action('plugins_loaded', [$this, '__load_dependencies'], 99);

        $initialized[] = $this->plugin_id;
      }

      wp_cache_set("__nc_initialized_hooks_list__", $initialized, "nc");

      if (method_exists($this, 'common_hooks')) {
        call_user_func([$this, 'common_hooks']);
      }

      if (is_admin() && method_exists($this, 'admin_hooks')) {
        call_user_func([$this, 'admin_hooks']);
      } else if (method_exists($this, 'public_hooks')) {
        call_user_func([$this, 'public_hooks']);
      }
    }

    /**
     * Set plugin directory
     * 
     * @param string $dir Plugin directory
     * 
     * @return NC_Hooks $this
     */
    private function __set_plugin_dir(string $dir)
    {
      if (!is_dir($dir)) {
        throw new Exception("Plugin directory not found");
      }

      $this->plugin_dir = $dir;
      $this->plugin_id = basename($this->plugin_dir);
      $this->assets_url = plugins_url('assets', $this->plugin_dir . '/_');
      $this->template_dir = $this->plugin_dir . '/templates';

      return $this;
    }

    /**
     * Load dependecies
     * 
     * @return void
     */
    final public function __load_dependencies()
    {
      foreach (glob($this->plugin_dir . "/dependencies/*.dependency.php") as $filename) include $filename;
    }

    /**
     * Switch language
     * 
     * @param string $locale Language
     * 
     * @return void
     */
    final public function switch_language(string $locale)
    {
      global $l10n;

      if (isset($l10n["sendeach"])) {
        $backup = $l10n["sendeach"];
      }

      load_textdomain("sendeach", realpath($this->plugin_dir . 'lang/' . $locale . '.mo'));

      return function () use ($backup) {
        global $l10n;

        if (isset($backup)) {
          $l10n["sendeach"] = $backup;
        }
      };
    }

    /**
     * Load template
     * 
     * @param string $template Template path
     * @param mixed[] $args Arguments to pass to a template
     * 
     * @return void
     */
    final public function load_template(string $template, array $args = [])
    {
      $template_path = preg_replace(['/^\//', '/.php$/'], ['', ''],  $template);
      $template_path = $this->get_templates_dir_path("{$template_path}.php");

      /**
       * Filter template path
       * 
       * @param string $template_path Template path
       * @param string $template Template path
       * @param mixed[] $args Arguments to pass to a template
       * @param string $plugin_id Plugin id
       * 
       * @return string
       */
      $template_path = apply_filters('nc_plugin_get_template', $template_path, $template, $args, $this->plugin_id);

      if (file_exists($template_path)) {
        extract($args);
        include $template_path;
      }
    }

    /**
     * Get asset url
     * 
     * @param string $path Path to asset
     * 
     * @return void
     */
    final public function get_asset_url(string $path)
    {
      $path = preg_replace(['/^\//'], [''], $path);
      $url = $this->assets_url . '/' . $path;

      /**
       * Filter asset url
       * 
       * @param string $url Asset url
       * @param string $path Path to asset
       * @param string $plugin_id Plugin id
       * 
       * @return string
       */
      return apply_filters('nc_plugin_get_asset_url', $url, $path, $this->plugin_id);
    }

    /**
     * Get templates dir path
     * 
     * @param string $path Optional file path
     * 
     * @return string
     */
    final public function get_templates_dir_path($path = '')
    {
      $new_path = $this->template_dir . '/' . $path;
      $new_path = realpath($new_path);

      /**
       * Filter template dir path
       * 
       * @param string $path Template dir path
       * @param string $plugin_id Plugin id
       * 
       * @return string
       */
      return apply_filters('nc_plugin_get_templates_dir_path', $new_path, $path, $this->plugin_id);
    }
  }
}
