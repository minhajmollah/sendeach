<?php

if (!defined('ABSPATH')) {
  exit;
}

if (!function_exists('nc_session')) {
  /**
   * Get session manager instance
   *
   * @return NC_Session_Manager
   */
  function nc_session()
  {
    return NC_Session_Manager::get_instance();
  }
}
